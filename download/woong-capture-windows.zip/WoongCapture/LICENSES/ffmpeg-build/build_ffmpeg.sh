#!/bin/bash
# 웅캡처용 작은 ffmpeg.exe 만들기 — 녹화에 꼭 필요한 부품만 넣는다(약 6MB).
# MSYS2 의 UCRT64 환경에서 돌린다. 준비와 사용법은 같은 폴더의 README.txt 를 볼 것.
#
#   C:\msys64\usr\bin\bash.exe -lc "/c/Users/.../tools/capture/engine_build/build_ffmpeg.sh"
#
# 결과: tools/capture/engine/ffmpeg.exe  +  tools/capture/engine/src/ (이 ffmpeg 를 만든 소스: GPL 에서 요구)
set -euo pipefail

# --- 만든 때의 버전(바꾸면 SHA256 도 같이 바꿀 것) ---
FF_VER=8.1.3
FF_SHA256=7138d28c96d9d3e3af4ee3d8cad72741f8ffb40da90c1112235dea3ecd3178a3
FF_KEY=FCF986EA15E6E293A5644F10B4322F04D67658D8          # FFmpeg release signing key
X264_URL=https://code.videolan.org/videolan/x264.git
X264_COMMIT=b35605ace3ddf7c1a5d67a2eb553f034aef41d55      # stable 가지, x264 0.165

HERE=$(cd "$(dirname "$0")" && pwd)
ENGINE=$(cd "$HERE/.." && pwd)/engine
WORK=${WORK:-/c/ffbuild}                                    # 짧은 경로 — 빌드가 길어진 경로에서 막히는 일을 피한다
case "$MSYSTEM" in UCRT64) ;; *) export PATH=/ucrt64/bin:$PATH ;; esac

mkdir -p "$WORK/src" "$ENGINE/src"
cd "$WORK/src"

# --- 1. 소스 받기 · 확인 ---
if [ ! -f ffmpeg-$FF_VER.tar.xz ]; then
  curl -fsSLO https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz
  curl -fsSLO https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz.asc
fi
echo "$FF_SHA256 *ffmpeg-$FF_VER.tar.xz" | sha256sum -c -
curl -fsSL https://ffmpeg.org/ffmpeg-devel.asc | gpg --import 2>/dev/null
gpg --status-fd 1 --verify ffmpeg-$FF_VER.tar.xz.asc ffmpeg-$FF_VER.tar.xz 2>/dev/null | grep -q "VALIDSIG.*$FF_KEY"   || { echo "ffmpeg 서명 확인 실패"; exit 1; }

if [ ! -d x264 ]; then
  git init -q x264
  git -C x264 remote add origin "$X264_URL"
  git -C x264 fetch -q --depth 1 origin "$X264_COMMIT" || git -C x264 fetch -q --depth 300 origin stable
  git -C x264 checkout -q "$X264_COMMIT"
fi
[ "$(git -C x264 rev-parse HEAD)" = "$X264_COMMIT" ] || { echo "x264 버전이 다름"; exit 1; }

rm -rf "$WORK/ffmpeg-$FF_VER"
tar xf ffmpeg-$FF_VER.tar.xz -C "$WORK"

# --- 2. x264 (H.264 부호기) — 8비트 · 4:2:0 만, 정적 라이브러리로 ---
rm -rf "$WORK/x264-build" "$WORK/prefix"
mkdir -p "$WORK/x264-build" && cd "$WORK/x264-build"
"$WORK/src/x264/configure" --prefix="$WORK/prefix" --enable-static --disable-cli --disable-opencl --disable-avs \
  --disable-swscale --disable-lavf --disable-ffms --disable-gpac --disable-lsmash --bit-depth=8 --chroma-format=420
make -j"$(nproc)" libx264.a
make install-lib-static

# --- 3. ffmpeg — 다 끄고 녹화에 쓰는 것만 켠다 ---
#  영상 입력  gdigrab(화면 찍기) · rawvideo(찍은 날것) · bmp(마우스 포인터 그림)
#  영상 출력  libx264 → mp4(녹화 중엔 조각 mp4, 멈추면 mov 를 다시 읽어 faststart 로 복사) · h264 parser
#  소리 합치기 pcm_s16le(받아 둔 날것 소리) → atrim · asetpts · adelay · aresample · aformat · amix · alimiter → aac
#  영상 가공  scale(크기 줄이기) · format(yuv420p) · fps · setpts
# recorder.py 가 ffmpeg 를 쓰는 방식을 바꾸면 여기도 맞추고 rec_test.py 로 다시 확인할 것.
rm -rf "$WORK/ff-build" && mkdir -p "$WORK/ff-build" && cd "$WORK/ff-build"
PKG_CONFIG_PATH="$WORK/prefix/lib/pkgconfig" "$WORK/ffmpeg-$FF_VER/configure" \
  --prefix="$WORK/ff-out" --pkg-config-flags=--static \
  --disable-everything --disable-autodetect --disable-network --disable-doc --disable-debug \
  --disable-ffplay --disable-ffprobe --disable-shared --enable-static \
  --enable-gpl --enable-libx264 \
  --extra-cflags="-I$WORK/prefix/include" --extra-ldflags="-L$WORK/prefix/lib" --extra-ldflags=-static \
  --enable-ffmpeg \
  --enable-indev=gdigrab \
  --enable-demuxer=mov,pcm_s16le --enable-muxer=mp4 \
  --enable-protocol=file,pipe \
  --enable-decoder=rawvideo,pcm_s16le --enable-encoder=libx264,aac \
  --enable-parser=h264,aac --enable-bsf=null,aac_adtstoasc \
  --enable-filter=buffer,buffersink,scale,format,fps,null,setpts,nullsink,abuffer,abuffersink,anull,atrim,asetpts,adelay,aresample,aformat,amix,alimiter
make -j"$(nproc)"

# --- 4. 결과 놓기 + 이 ffmpeg 를 만든 소스(GPL) ---
cp -f ffmpeg.exe "$ENGINE/ffmpeg.exe"
cp -f "$WORK/src/ffmpeg-$FF_VER.tar.xz" "$WORK/src/ffmpeg-$FF_VER.tar.xz.asc" "$ENGINE/src/"
git -C "$WORK/src/x264" archive --format=tar.gz --prefix="x264-${X264_COMMIT:0:8}/" -o "$ENGINE/src/x264-${X264_COMMIT:0:8}.tar.gz" HEAD
( cd "$ENGINE/src" && sha256sum * > SHA256SUMS.txt )
echo
echo "== 끝 =="
ls -l "$ENGINE/ffmpeg.exe"
sha256sum "$ENGINE/ffmpeg.exe"
"$ENGINE/ffmpeg.exe" -hide_banner -version | head -2
cat "$ENGINE/src/SHA256SUMS.txt"
