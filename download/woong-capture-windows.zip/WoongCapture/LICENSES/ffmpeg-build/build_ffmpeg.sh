#!/bin/bash
# 웅캡처용 작은 ffmpeg.exe 만들기 — 녹화에 꼭 필요한 부품만 넣는다(약 4MB).
# MSYS2 의 UCRT64 환경에서 돌린다. 준비와 사용법은 같은 폴더의 README.txt 를 볼 것.
#
#   C:\msys64\usr\bin\bash.exe -lc "/c/Users/.../tools/capture/engine_build/build_ffmpeg.sh"
#
# 결과: tools/capture/engine/ffmpeg.exe  +  tools/capture/engine/src/ (만든 소스 원본 보관용)
#
# 라이선스를 가볍게 두려고 GPL 부품(x264 등)은 넣지 않는다 → 결과는 LGPL-3.0 이상.
# 영상 · 소리 부호기는 Windows 에 들어 있는 Media Foundation(h264_mf · aac_mf)을 불러 쓴다
# (H.264 · AAC 특허 사용료는 Windows 쪽에서 이미 해결돼 있어, 우리 배포물에는 부호기 자체가 없다).
set -euo pipefail

# --- 만든 때의 버전(바꾸면 SHA256 도 같이 바꿀 것) ---
FF_VER=8.1.3
FF_SHA256=7138d28c96d9d3e3af4ee3d8cad72741f8ffb40da90c1112235dea3ecd3178a3
FF_KEY=FCF986EA15E6E293A5644F10B4322F04D67658D8          # FFmpeg release signing key

HERE=$(cd "$(dirname "$0")" && pwd)
ENGINE=$(cd "$HERE/.." && pwd)/engine
WORK=${WORK:-/c/ffbuild}                                    # 짧은 경로 — 빌드가 길어진 경로에서 막히는 일을 피한다
case "$MSYSTEM" in UCRT64) ;; *) export PATH=/ucrt64/bin:$PATH ;; esac

mkdir -p "$WORK/src" "$ENGINE/src"
cd "$WORK/src"

# --- 1. 소스 받기 · 확인(해시 + FFmpeg 공식 서명) ---
if [ ! -f ffmpeg-$FF_VER.tar.xz ]; then
  curl -fsSLO https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz
  curl -fsSLO https://ffmpeg.org/releases/ffmpeg-$FF_VER.tar.xz.asc
fi
echo "$FF_SHA256 *ffmpeg-$FF_VER.tar.xz" | sha256sum -c -
curl -fsSL https://ffmpeg.org/ffmpeg-devel.asc | gpg --import 2>/dev/null
gpg --status-fd 1 --verify ffmpeg-$FF_VER.tar.xz.asc ffmpeg-$FF_VER.tar.xz 2>/dev/null | grep -q "VALIDSIG.*$FF_KEY" \
  || { echo "ffmpeg 서명 확인 실패"; exit 1; }

rm -rf "$WORK/ffmpeg-$FF_VER"
tar xf ffmpeg-$FF_VER.tar.xz -C "$WORK"

# 윈도우 파일 정보(만든 곳 · 버전 · 설명)를 더한다 — 코드는 그대로, 리소스 파일(fftoolsres.rc)에 표시만 추가.
# 이게 없으면 BitDefender 엔진을 쓰는 백신(알약 · GData · Emsisoft 등)이 'Gen:Variant.Ulise' 로 오진했다
# (2026-10-26 VirusTotal: 정보 없음 7/64 → 정보 넣음 0/64).
V=${FF_VER//./,}
cat >> "$WORK/ffmpeg-$FF_VER/fftools/fftoolsres.rc" <<EOF

1 VERSIONINFO
FILEVERSION $V,0
PRODUCTVERSION $V,0
FILEFLAGSMASK 0x3f
FILEFLAGS 0x0
FILEOS 0x40004
FILETYPE 0x1
FILESUBTYPE 0x0
BEGIN
  BLOCK "StringFileInfo"
  BEGIN
    BLOCK "040904B0"
    BEGIN
      VALUE "CompanyName", "FFmpeg project"
      VALUE "FileDescription", "FFmpeg screen recording engine for woong capture"
      VALUE "FileVersion", "$FF_VER"
      VALUE "InternalName", "ffmpeg"
      VALUE "LegalCopyright", "Copyright (c) 2000-2026 the FFmpeg developers. LGPL-3.0-or-later"
      VALUE "OriginalFilename", "ffmpeg.exe"
      VALUE "ProductName", "FFmpeg"
      VALUE "ProductVersion", "$FF_VER"
    END
  END
  BLOCK "VarFileInfo"
  BEGIN
    VALUE "Translation", 0x409, 1200
  END
END
EOF

# --- 2. ffmpeg — 다 끄고 녹화에 쓰는 것만 켠다 ---
#  영상 입력  gdigrab(화면 찍기) · rawvideo(찍은 날것) · bmp(마우스 포인터 그림)
#  영상 출력  h264_mf(Windows 의 H.264) → mp4(녹화 중엔 조각 mp4, 멈추면 mov 를 다시 읽어 faststart 로 복사) · h264 parser
#  소리 합치기 pcm_s16le(받아 둔 날것 소리) → atrim · asetpts · adelay · aresample · aformat · amix · alimiter → aac_mf
#  영상 가공  scale(크기 줄이기) · format(yuv420p) · fps · setpts
# recorder.py 가 ffmpeg 를 쓰는 방식을 바꾸면 여기도 맞추고 rec_test.py 로 다시 확인할 것.
rm -rf "$WORK/ff-build" && mkdir -p "$WORK/ff-build" && cd "$WORK/ff-build"
"$WORK/ffmpeg-$FF_VER/configure" \
  --prefix="$WORK/ff-out" \
  --disable-everything --disable-autodetect --disable-network --disable-doc --disable-debug \
  --disable-ffplay --disable-ffprobe --disable-shared --enable-static \
  --enable-version3 --enable-mediafoundation --enable-d3d11va \
  --extra-ldflags=-static \
  --enable-ffmpeg \
  --enable-indev=gdigrab \
  --enable-demuxer=mov,pcm_s16le --enable-muxer=mp4 \
  --enable-protocol=file,pipe \
  --enable-decoder=rawvideo,pcm_s16le --enable-encoder=h264_mf,aac_mf \
  --enable-parser=h264 --enable-bsf=null \
  --enable-filter=buffer,buffersink,scale,format,fps,null,setpts,nullsink,abuffer,abuffersink,anull,atrim,asetpts,adelay,aresample,aformat,amix,alimiter
make -j"$(nproc)"
./ffmpeg.exe -hide_banner -L 2>/dev/null | grep -q "GNU Lesser General Public License" || { echo "LGPL 이 아님 — 설정 확인"; exit 1; }

# --- 3. 결과 놓기 + 만든 소스 원본 보관 ---
cp -f ffmpeg.exe "$ENGINE/ffmpeg.exe"
rm -f "$ENGINE"/src/x264-*.tar.gz
cp -f "$WORK/src/ffmpeg-$FF_VER.tar.xz" "$WORK/src/ffmpeg-$FF_VER.tar.xz.asc" "$ENGINE/src/"
( cd "$ENGINE/src" && sha256sum * > SHA256SUMS.txt )
echo
echo "== 끝 =="
ls -l "$ENGINE/ffmpeg.exe"
sha256sum "$ENGINE/ffmpeg.exe"
"$ENGINE/ffmpeg.exe" -hide_banner -version | head -2
"$ENGINE/ffmpeg.exe" -hide_banner -L | head -3
