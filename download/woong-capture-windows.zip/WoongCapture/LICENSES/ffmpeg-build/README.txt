작은 ffmpeg.exe 만들기 (웅캡처 화면 녹화용)
==========================================

■ 왜 직접 만드나요?
  웅캡처 녹화는 ffmpeg 라는 프로그램을 따로 불러서 씁니다. 인터넷에 있는 ffmpeg 는 100MB 가 넘고,
  대부분 GPL 부품(x264 등)이 들어 있어 배포 조건이 무거워요. 그래서 녹화에 꼭 필요한 부분만 골라
  직접 컴파일했어요. 결과는 약 4.4MB (압축하면 2MB 쯤).

■ 법적으로 가볍게 만든 방법
  · GPL · nonfree 부품은 하나도 넣지 않아요 → 결과 ffmpeg.exe 는 LGPL-3.0 (빌드 스크립트가 확인하고, 아니면 멈춰요).
    LGPL 은 "공식 소스 받는 곳을 알려 주는 것"으로 충분해서, 우리가 소스를 따로 나눠 줄 필요가 없어요.
    웅캡처 본체는 ffmpeg.exe 를 따로 실행만 하므로, 웅캡처 코드는 공개할 필요가 전혀 없어요.
  · 영상(H.264) · 소리(AAC)는 Windows 에 들어 있는 Media Foundation 부호기(h264_mf · aac_mf)를 불러 써요.
    H.264 · AAC 특허 사용료는 Windows 쪽에서 이미 해결돼 있고, 우리 배포물에는 부호기가 아예 없어요.
    (x264 와 비교: 같은 화질에서 파일이 30~40% 커요. 화면 녹화엔 충분해요 — 2026-10-26 비교 시험)
  · Windows N · KN 판(미디어 기능이 빠진 판)은 '미디어 기능 팩'을 깔아야 녹화돼요 — 웅캡처가 안내 창을 띄워요.

■ 어디에 있나요?
  · tools\capture\engine\ffmpeg.exe ........ 만든 결과 (git 에는 안 올림 — .gitignore 의 engine/)
  · tools\capture\engine\src\ ................ 만든 소스 원본 보관용 (FFmpeg 공식 서버가 없어질 때를 대비, git 밖)
  · build.py 가 engine\ffmpeg.exe 가 있으면 WoongCapture.exe 옆에 같이 넣어요 (설치하면 설치 폴더에도 같이 깔림).
    웅캡처가 ffmpeg 를 찾는 순서: exe 옆 ffmpeg.exe → engine\ → %LOCALAPPDATA%\WoongCapture\engine → PATH → winget 자리.

■ 안에 들어 있는 것 (이 밖의 것은 일부러 뺐어요)
  · 화면 찍기: gdigrab (Windows 화면 캡처) · 날것 영상/비트맵 읽기
  · 영상 만들기: h264_mf (Windows 의 H.264) → mp4 (녹화 중엔 조각 mp4, 멈추면 다시 읽어서 앞쪽에 목차를 둔 mp4 로 복사)
  · 영상 다듬기: scale(크기 줄이기) · format(yuv420p) · fps
  · 소리 합치기: 날것 소리(pcm_s16le) 읽기 → atrim · adelay · asetpts · aresample · aformat · amix · alimiter → aac_mf
  · 파일 입출력만 — 인터넷 · 장치(카메라 · 마이크 직접 접근) · 다른 코덱 · ffplay · ffprobe 는 뺐어요.

■ 다시 만들기 (ffmpeg 버전을 올릴 때, 또는 recorder.py 가 ffmpeg 를 쓰는 방식이 달라졌을 때)
  1. MSYS2 깔기 (한 번만) — PowerShell 에서:
       winget install --id MSYS2.MSYS2 -e --location C:\msys64
  2. 도구 깔기 (한 번만) — 아래를 차례로. 첫 줄은 두 번 돌려요(처음엔 자기 자신을 갱신하다 끝나요).
       C:\msys64\usr\bin\bash.exe -lc "pacman -Syu --noconfirm"
       C:\msys64\usr\bin\bash.exe -lc "pacman -S --noconfirm --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-nasm mingw-w64-ucrt-x86_64-pkgconf make diffutils git curl xz tar gnupg"
  3. 만들기 (2~3분) — 소스를 받아 서명 · 해시를 확인하고 빌드해요:
       C:\msys64\usr\bin\bash.exe -lc "/c/Users/(내 이름)/Desktop/work_hub/tools/capture/engine_build/build_ffmpeg.sh"
     (작업 폴더는 기본 C:\ffbuild, 바꾸려면 앞에 WORK=/c/다른폴더 를 붙여요)
  4. 확인 — 분홍 창 하나만 띄워 그 자리를 녹화하고 영상 속(프레임 전부 분홍 · H.264 · yuv420p · 목차 앞쪽 · 소리)을 봐요:
       tools\capture\.venv\Scripts\python.exe rec_test.py
     판정은 winget 으로 깐 전체판 ffmpeg/ffprobe (winget install Gyan.FFmpeg)로 해요.

■ recorder.py 를 고쳐서 ffmpeg 에 새 일을 시킬 때
  새 필터 · 부호기 · 입력을 쓰면 build_ffmpeg.sh 의 --enable-* 목록에 더하고 다시 만들어야 해요.
  빼먹으면 녹화할 때 "No such filter" 같은 오류가 나요. rec_test.py 에 그 경로를 쓰는 시험을 더해 두면 좋아요.
  ※ --enable-gpl · --enable-libx264 · --enable-nonfree 는 절대 넣지 마세요 (배포 조건이 무거워져요).
     build.py 의 smoke 점검이 매번 h264_mf · aac_mf · gdigrab · LGPL 인지를 봐요.
