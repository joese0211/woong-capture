작은 ffmpeg.exe 만들기 (웅캡처 화면 녹화용)
==========================================

■ 왜 직접 만드나요?
  웅캡처 녹화는 ffmpeg 라는 프로그램을 따로 불러서 씁니다. 인터넷에 있는 ffmpeg 는 100MB 가 넘어서
  그대로 담으면 웅캡처 압축 파일이 몇 배로 커져요. 그래서 녹화에 꼭 필요한 부분만 골라 직접 컴파일했어요.
  결과는 약 6MB (압축하면 2~3MB).

■ 어디에 있나요?
  · tools\capture\engine\ffmpeg.exe ........ 만든 결과 (git 에는 안 올림 — .gitignore 의 engine/)
  · tools\capture\engine\src\ ................ 이 ffmpeg 를 만든 소스 원본 + SHA256SUMS.txt (GPL 소스 제공용, git 에는 안 올림)
  · build.py 가 engine\ffmpeg.exe 가 있으면 WoongCapture.exe 옆에 같이 넣어요 (설치하면 설치 폴더에도 같이 깔림).
    웅캡처가 ffmpeg 를 찾는 순서: exe 옆 ffmpeg.exe → engine\ → %LOCALAPPDATA%\WoongCapture\engine → PATH → winget 자리.

■ 안에 들어 있는 것 (이 밖의 것은 일부러 뺐어요)
  · 화면 찍기: gdigrab (Windows 화면 캡처) · 날것 영상/비트맵 읽기
  · 영상 만들기: libx264 (H.264) → mp4 (녹화 중엔 조각 mp4, 멈추면 다시 읽어서 앞쪽에 목차를 둔 mp4 로 복사)
  · 영상 다듬기: scale(크기 줄이기) · format(yuv420p) · fps
  · 소리 합치기: 날것 소리(pcm_s16le) 읽기 → atrim · adelay · asetpts · aresample · aformat · amix · alimiter → AAC
  · 파일 입출력만 — 인터넷 · 장치(카메라 · 마이크 직접 접근) · 다른 코덱 · ffplay · ffprobe 는 뺐어요.
  · 라이선스: x264 때문에 GPL (GPL-2.0-or-later). 고지는 LICENSES\THIRD-PARTY-NOTICES.txt 5번에 있어요.

■ 다시 만들기 (ffmpeg 버전을 올릴 때, 또는 recorder.py 가 ffmpeg 를 쓰는 방식이 달라졌을 때)
  1. MSYS2 깔기 (한 번만) — PowerShell 에서:
       winget install --id MSYS2.MSYS2 -e --location C:\msys64
  2. 도구 깔기 (한 번만) — 아래를 차례로. 첫 줄은 두 번 돌려요(처음엔 자기 자신을 갱신하다 끝나요).
       C:\msys64\usr\bin\bash.exe -lc "pacman -Syu --noconfirm"
       C:\msys64\usr\bin\bash.exe -lc "pacman -S --noconfirm --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-nasm mingw-w64-ucrt-x86_64-pkgconf make diffutils git curl xz tar gnupg"
  3. 만들기 (3~5분) — 소스를 받아 서명 · 해시를 확인하고 x264 → ffmpeg 순서로 빌드해요:
       C:\msys64\usr\bin\bash.exe -lc "/c/Users/(내 이름)/Desktop/work_hub/tools/capture/engine_build/build_ffmpeg.sh"
     (작업 폴더는 기본 C:\ffbuild, 바꾸려면 앞에 WORK=/c/다른폴더 를 붙여요)
  4. 확인 — 분홍 창 하나만 띄워 그 자리를 녹화하고 영상 속(프레임 전부 분홍 · H.264 · yuv420p · 목차 앞쪽 · 소리)을 봐요:
       tools\capture\.venv\Scripts\python.exe rec_test.py
     판정은 winget 으로 깐 전체판 ffmpeg/ffprobe (winget install Gyan.FFmpeg)로 해요.

■ recorder.py 를 고쳐서 ffmpeg 에 새 일을 시킬 때
  새 필터 · 부호기 · 입력을 쓰면 build_ffmpeg.sh 의 --enable-* 목록에 더하고 다시 만들어야 해요.
  빼먹으면 녹화할 때 "No such filter" 같은 오류가 나요. rec_test.py 에 그 경로를 쓰는 시험을 더해 두면 좋아요.
  (build.py 의 smoke 점검도 부호기 libx264 · aac · gdigrab 이 있는지는 매번 봐요.)

■ 소스 제공(GPL)
  이 ffmpeg.exe 를 배포할 땐 고지문(LICENSES\THIRD-PARTY-NOTICES.txt, GPL-2.0.txt)이 꼭 같이 들어가야 해요.
  build.py 가 알아서 넣어요. 공개 저장소에 소스 원본도 같이 올려 두려면 engine\src\ 의 두 파일
  (ffmpeg-8.1.3.tar.xz · x264-b35605ac.tar.gz)을 올리면 돼요 (올리기 전에 사장님 허락 받기).
